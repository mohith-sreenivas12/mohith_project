# Jango12
This is a project of poll application using python and django.
