# django-poll-application

> Source code of the official django tutorial from https://docs.djangoproject.com/en/1.9/intro/tutorial01/
